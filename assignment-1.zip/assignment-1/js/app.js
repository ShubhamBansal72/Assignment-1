
// $(document).ready(function () {
//     $('.carousel').slick({
//         slidesToShow: 1,
//         // dots:true,
//         // centerMode: true,

//     });
//     if (width() < 992) {
//         $('.carousel').unslick({
//             // slidesToShow: 1,
//             // dots:true,
//             // centerMode: true,
//         });
//     }


// });

$(document).ready(function () {
    if($(window).width() < 992){
        $('.carousel').slick();
    }
     else{
        responsive: [
            {
               breakpoint: 767,
               settings: "slick"
            }
         ]
     }

});



function myFunction() {
    var x = document.getElementById("myLinks");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }
  }